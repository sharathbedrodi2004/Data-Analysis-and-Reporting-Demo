
-- Total Sales by Region
SELECT Region, SUM(Sales) AS Total_Sales
FROM sales
GROUP BY Region;

-- Average Sales
SELECT AVG(Sales) AS Average_Sales FROM sales;

-- Top 5 Sales Records
SELECT * FROM sales
ORDER BY Sales DESC
LIMIT 5;
