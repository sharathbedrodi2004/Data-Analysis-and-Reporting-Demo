
Data Analysis & Reporting Demo

Tools Used:
- Microsoft Excel
- SQL (SQLite)

Description:
- Analyzed sales dataset using Excel and SQL
- Generated KPIs such as total sales by region, average sales, and top-performing records
- Documented insights for business decision-making

Files:
- sales_analysis.xlsx : Excel dataset for analysis and dashboards
- sales_data.db : SQLite database
- analysis_queries.sql : SQL queries used for analysis
